//
//  ViewController.swift
//  how to use image masking in swift 4 xcode 9
//
//  Created by Abhishek Verma on 14/07/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ProfileMaskingImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let maskImageview   = UIImageView()
        maskImageview.image = #imageLiteral(resourceName: "MaskingImage")
        maskImageview.frame = ProfileMaskingImage.bounds
        ProfileMaskingImage.mask = maskImageview
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

